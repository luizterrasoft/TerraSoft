New languages : http://www.usercontrol.com.br/languages.php

To install new language in your usercontrol copy the new file UCConsts.pas in folder: "Usercontrol"\Source.


You can to create a new language unit for User Control Package editing the UCConsts.pas file

Please don't forget to send me this :) Thank You! (qmd@usercontrol.com.br)

